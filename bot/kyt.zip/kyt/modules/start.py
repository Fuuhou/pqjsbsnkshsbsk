from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:\.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    sender = await event.get_sender()

    # Validasi akses user
    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    # Ambil waktu lokal
    time_info = safe_exec("LC_TIME=id_ID.UTF-8 date '+%A, %d %B %Y - %H:%M WIB'")

    # Pesan panel
    msg = (
        "━━━━━━━━━━━━━━━━━━━━\n"
        "**PANEL XIESTORE**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"**Owner :** @superxiez\n"
        f"**Group :** @xiestorez\n"
        f"**Channel :** @xiechannel\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"__{time_info}__"
    )

    # Kirim pesan
    try:
        sent = await event.edit(msg)
        if not sent:
            await event.reply(msg)
    except Exception:
        await event.reply(msg)
