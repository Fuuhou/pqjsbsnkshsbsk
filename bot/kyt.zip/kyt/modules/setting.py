import os
import subprocess
import requests
from kyt import *
from telethon import events, Button


async def check_access(event):
    """Validasi user, kembalikan True jika diizinkan."""
    sender = await event.get_sender()
    return valid(str(sender.id)) == "true"

@bot.on(events.CallbackQuery(data=b'reboot'))
async def reboot_server(event):
    if not await check_access(event):
        return await event.answer("Access Denied", alert=True)
    await event.edit("**REBOOT SERVER**", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])
    safe_exec("shutdown -r now")

@bot.on(events.CallbackQuery(data=b'resx'))
async def restart_services(event):
    if not await check_access(event):
        return await event.answer("Access Denied", alert=True)
    safe_exec("systemctl restart xray && systemctl restart nginx && systemctl restart haproxy && systemctl restart server && systemctl restart client")
    await event.edit("**Restarting Service Done**", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])

@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
    if not await check_access(event):
        return await event.answer("Access Denied", alert=True)
    result = safe_exec("speedtest-cli --share")
    await event.edit(f"**\n{result}\n**\n**» Success**", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])

@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
    if not await check_access(event):
        return await event.answer("Access Denied", alert=True)
    safe_exec('printf "%s\n" "3" | m-backup')
    await event.edit("**» Success**", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])

@bot.on(events.CallbackQuery(data=b'restore'))
async def restore(event):
    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)
    sender = await event.get_sender()
    chat = event.chat_id
    async with bot.conversation(chat) as conv:
        await event.respond("**» LINK BACKUP :**")
        msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        link = msg.raw_text.strip()
    safe_exec(f'printf "%s\n" "1" "{link}" | m-backup')
    await event.respond("**» SUCCES RESTORE AKUN**\n**» DONE**", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])

@bot.on(events.CallbackQuery(data=b'backer'))
async def backup_restore_menu(event):
    if not await check_access(event):
        return await event.answer("Access Denied", alert=True)
    ip_addr = safe_file("/etc/myipvps")
    domainz = safe_file("/etc/xray/domain")
    isp = safe_file("/etc/xray/isp")
    city = safe_file("/etc/xray/city")
    profil = safe_file("/etc/profil")
    time_info = safe_exec("LC_TIME=id_ID.UTF-8 date '+%A, %d %B %Y - %H:%M WIB'")
    msg = (
        "━━━━━━━━━━━━━━━━━━━━\n"
        "**PANEL XIESTORE**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"**IP :** {ip_addr}\n"
        f"**Domain :** {domainz}\n"
        f"**ISP :** {isp}\n"
        f"**Kota :** {city}\n"
        f"**Profil :** {profil}\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"__{time_info}__"
    )
    buttons = [
        [Button.inline(" BACKUP", b"backup"), Button.inline(" RESTORE", b"restore")],
        [Button.inline("‹ Main Menu ›", b"menu")]
    ]
    await event.edit(msg, buttons=buttons)

@bot.on(events.CallbackQuery(data=b'setting'))
async def settings_menu(event):
    if not await check_access(event):
        return await event.answer("Access Denied", alert=True)
    ip_addr = safe_file("/etc/myipvps")
    domainz = safe_file("/etc/xray/domain")
    isp = safe_file("/etc/xray/isp")
    city = safe_file("/etc/xray/city")
    profil = safe_file("/etc/profil")
    time_info = safe_exec("LC_TIME=id_ID.UTF-8 date '+%A, %d %B %Y - %H:%M WIB'")
    msg = (
        "━━━━━━━━━━━━━━━━━━━━\n"
        "**PANEL XIESTORE**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"**IP :** {ip_addr}\n"
        f"**Domain :** {domainz}\n"
        f"**ISP :** {isp}\n"
        f"**Kota :** {city}\n"
        f"**Profil :** {profil}\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"__{time_info}__"
    )
    buttons = [
        [Button.inline(" SPEEDTEST", b"speedtest"), Button.inline(" BACKUP & RESTORE", b"backer")],
        [Button.inline(" REBOOT SERVER", b"reboot"), Button.inline(" RESTART SERVICE", b"resx")],
        [Button.inline("‹ Main Menu ›", b"menu")]
    ]
    await event.edit(msg, buttons=buttons)
