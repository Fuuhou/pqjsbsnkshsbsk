from kyt import *

import os
import subprocess
import datetime as dt
from telethon import events, Button

@bot.on(events.NewMessage(pattern=r"^(?:\.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Validasi akses user
    if valid(user_id) != "true":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except Exception:
            await event.reply("Akses Ditolak")
        return

    # Hitung akun VPN
    ssh_count    = safe_count("###", "/etc/xray/ssh")
    vmess_count  = safe_count("#vmg", "/etc/xray/config.json")
    vless_count  = safe_count("#vlg", "/etc/xray/config.json")
    trojan_count = safe_count("#trg", "/etc/xray/config.json")

    # Informasi sistem
    ip_addr   = safe_file("/etc/myipvps")
    isp       = safe_file("/etc/xray/isp")
    city      = safe_file("/etc/xray/city")
    profil    = safe_file("/etc/profil")
    domainz   = safe_file("/etc/xray/domain")
    time_info = safe_exec("LC_TIME=id_ID.UTF-8 date '+%A, %d %B %Y - %H:%M WIB'")

    # Uptime bot & server
    uptime_bot_start = dt.datetime.now()  # jika ingin simpan waktu start bot
    uptime_server    = subprocess.getoutput("uptime -p")  # contoh: 'up 3 hours, 12 minutes'

    # Struktur tombol menu
    inline_buttons = [
        [Button.inline(" MENU SSH ", b"ssh"), Button.inline(" MENU VMESS ", b"vmess")],
        [Button.inline(" MENU VLESS ", b"vless"), Button.inline(" MENU TROJAN ", b"trojan")],
        [Button.inline(" VPS INFO ", b"info"), Button.inline(" SETTING ", b"setting")]
    ]

    # Pesan panel
    msg = (
        "━━━━━━━━━━━━━━━━━━━━\n"
        "**PANEL XIESTORE**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"**IP :** {ip_addr}\n"
        f"**Domain :** {domainz}\n"
        f"**ISP :** {isp}\n"
        f"**Kota :** {city}\n"
        f"**Profil :** {profil}\n"
        f"**Up Bot :** {uptime_bot}\n"
        f"**Up Server :** {uptime_server}\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "TOTAL AKUN VPN\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"**SSH :** {ssh_count}\n"
        f"**VMESS :** {vmess_count}\n"
        f"**VLESS :** {vless_count}\n"
        f"**TROJAN :** {trojan_count}\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"__{time_info}__"
    )

    # Kirim atau edit pesan
    try:
        sent = await event.edit(msg, buttons=inline_buttons)
        if not sent:
            await event.reply(msg, buttons=inline_buttons)
    except Exception:
        await event.reply(msg, buttons=inline_buttons)


# Tombol cancel global handler
@bot.on(events.CallbackQuery(data=b'cancel'))
async def cancel_handler(event):
    await event.edit("⬤ CANCEL", buttons=[[Button.inline("‹ Main Menu ›", b"menu")]])
