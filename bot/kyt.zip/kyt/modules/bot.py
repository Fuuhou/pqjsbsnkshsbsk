import os
import logging
from dotenv import load_dotenv
from telethon import TelegramClient, events
from sima_api import get_produk, beli_produk, request_otp, get_riwayat
from kyt import *

load_dotenv()

# --- Helper Template ---
def format_produk_list(data: list) -> str:
    text = "📦 *Daftar Produk XL:*\n\n"
    for p in data[:10]:
        text += f"📌 *{p['nama_produk']}*\nKode: `{p['produk_code']}`\n"
        text += f"Harga: Rp {p['harga_bayar']:,}\nMetode: {p['deskripsi']}\n"
        text += f"Status: {p['status']}\n\n"
    return text

def format_riwayat(data: dict) -> str:
    head = (
        f"📊 Total transaksi: {data['totalTransaksi']}\n"
        f"✅ Sukses: {data['transaksiSukses']}\n"
        f"❌ Gagal: {data['transaksiGagal']}\n"
        f"💰 Saldo Terpakai: Rp {data['totalSaldoTerpakai']}\n\n"
    )
    body = ""
    for trx in data["transaksi"][:5]:
        body += (
            f"🧾 *{trx['nama_produk']}* ({trx['status_transaksi']})\n"
            f"Nomor: `{trx['catatan']}`\nMetode: {trx['metode_pembayaran']}\n"
            f"Jumlah: Rp {trx['jumlah']}\nTanggal: {trx['tanggal_transaksi']}\n\n"
        )
    return head + body

def format_transaksi(data: dict) -> str:
    result = (
        f"✅ *Pembelian Berhasil!*\n\nProduk: *{data['produk']}*\n"
        f"Harga: Rp {data['harga']}\nNomor: `{data['catatan']}`\n"
        f"Pembayaran: {data['metode_pembayaran']}\n"
        f"Saldo Tersisa: Rp {data['saldo_terakhir']}\n"
    )
    if data.get("link_pembayaran"):
        result += f"[🔗 Bayar Sekarang]({data['link_pembayaran']})"
    return result

# --- Command Handlers ---
@bot.on(events.NewMessage(pattern=r"^/start$"))
async def start(event):
    await event.respond(
        "**Selamat datang di Bot XL SIMA!**\n\n"
        "Perintah tersedia:\n"
        "/produk - Lihat produk XL\n"
        "/riwayat - Riwayat transaksi\n"
        "/beli <kode> <nomor> <metode>\n"
        "Contoh: `/beli AKBXXL 628123456789 DANA`",
        parse_mode="markdown"
    )

@bot.on(events.NewMessage(pattern=r"^/produk$"))
async def produk(event):
    await event.respond("📡 Mengambil daftar produk...")
    try:
        res = get_produk()
        if res.get("success") and "data" in res:
            text = format_produk_list(res["data"])
        else:
            text = "⚠️ Gagal memuat data produk."
    except Exception as e:
        text = f"❌ Error: {e}"
    await event.respond(text, parse_mode="markdown")

@bot.on(events.NewMessage(pattern=r"^/riwayat$"))
async def riwayat(event):
    await event.respond("📡 Mengambil riwayat transaksi...")
    try:
        res = get_riwayat()
        if res.get("success") and "data" in res:
            text = format_riwayat(res["data"])
        else:
            text = "⚠️ Gagal mengambil riwayat transaksi."
    except Exception as e:
        text = f"❌ Error: {e}"
    await event.respond(text, parse_mode="markdown")

@bot.on(events.NewMessage(pattern=r"^/beli\s+(\S+)\s+(\d+)\s+(\S+)$"))
async def beli(event):
    produk_code, msisdn, metode = event.pattern_match.groups()
    await event.respond(f"🛒 Membeli {produk_code} untuk {msisdn} via {metode.upper()}...")

    try:
        res = beli_produk(produk_code, msisdn, metode)
        if res.get("success") and "data" in res:
            text = format_transaksi(res["data"])
        else:
            text = "❌ Gagal melakukan pembelian."
    except Exception as e:
        text = f"❌ Error: {e}"
    await event.respond(text, parse_mode="markdown", link_preview=False)

@bot.on(events.NewMessage(pattern=r"/otp\s+(\d+)", incoming=True))
async def otp(event):
    msisdn = event.pattern_match.group(1)
    await event.respond(f"📲 Mengirim OTP ke `{msisdn}`...")

    try:
        res = request_otp(msisdn)
        if res.get("success"):
            await event.respond("✅ OTP berhasil dikirim. Silakan masukkan OTP kamu dengan format:\n`/verif <nomor> <kode>`", parse_mode="markdown")
        else:
            await event.respond(f"❌ Gagal kirim OTP: {res.get('message', 'Unknown error')}")
    except Exception as e:
        await event.respond(f"⚠️ Error saat kirim OTP: {e}")

@bot.on(events.NewMessage(pattern=r"/verif\s+(\d+)\s+(\d+)", incoming=True))
async def verifikasi_otp(event):
    msisdn, otp_code = event.pattern_match.groups()
    await event.respond(f"🔐 Memverifikasi OTP `{otp_code}` untuk `{msisdn}`...")

    try:
        res = verify_otp(msisdn, otp_code)
        if res.get("success"):
            await event.respond("✅ OTP berhasil diverifikasi. Kamu sudah login!")
        else:
            await event.respond(f"❌ Verifikasi gagal: {res.get('message', 'OTP tidak valid')}")
    except Exception as e:
        await event.respond(f"⚠️ Error saat verifikasi OTP: {e}")
