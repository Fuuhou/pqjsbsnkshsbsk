import os
import json
import time
import base64
import hashlib
import requests
from dotenv import load_dotenv
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes


# === Konfigurasi Environment ===
def load_env_config():
    load_dotenv()
    username = os.getenv("API_USERNAME")
    api_key = os.getenv("API_KEY")
    base_url = "https://www.simalakama.my.id"

    if not username or not api_key:
        raise EnvironmentError("❌ API_USERNAME atau API_KEY tidak ditemukan di file .env")

    return username, api_key, base_url


API_USERNAME, API_KEY, BASE_URL = load_env_config()


# === Utility: Enkripsi & Header ===
def _pad(data: str) -> bytes:
    pad_len = 16 - len(data) % 16
    return data.encode() + bytes([pad_len] * pad_len)

def _encrypt(payload: dict, key: str, use_sha256: bool = True) -> str:
    raw_json = json.dumps(payload)
    key_bytes = hashlib.sha256(key.encode()).digest() if use_sha256 else bytes.fromhex(key)
    iv = get_random_bytes(16)
    cipher = AES.new(key_bytes, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(_pad(raw_json))
    return base64.b64encode(encrypted + b"::" + iv).decode()

def _headers(xdata: str) -> dict:
    return {
        "username": API_USERNAME,
        "xdata": xdata,
        "xtime": str(int(time.time()))
    }


# === Utility: Signature & Key ===
def _generate_signature(command: str) -> str:
    return hashlib.md5(f"{API_USERNAME}{API_KEY}{command}".encode()).hexdigest()

def _generate_custom_key(command: str, signature: str) -> str:
    return hashlib.md5(f"{API_KEY}{signature}{command}".encode()).hexdigest()


# === API Functions: Produk & Transaksi ===
def get_produk():
    command = "detail-paket"
    signature = _generate_signature(command)
    key = _generate_custom_key(command, signature)
    payload = {"command": command}
    xdata = _encrypt(payload, key, use_sha256=False)
    url = f"{BASE_URL}/api/get-all-produkXL"
    response = requests.post(url, headers=_headers(xdata))
    return response.json()

def get_riwayat():
    command = "transaksi"
    signature = _generate_signature(command)
    payload = {
        "command": command,
        "signature": signature
    }
    xdata = _encrypt(payload, API_KEY)
    url = f"{BASE_URL}/api/get-transaksi"
    response = requests.post(url, headers=_headers(xdata))
    return response.json()

def beli_produk(produk_code: str, msisdn: str, metode: str):
    command = "beli-produk"
    signature = _generate_signature(command)
    payload = {
        "api_username": API_USERNAME,
        "api_key": API_KEY,
        "produk_code": produk_code,
        "msisdn": msisdn,
        "pay": metode.upper(),
        "signature": signature
    }
    xdata = _encrypt(payload, API_KEY)
    url = f"{BASE_URL}/api/beli-produk"
    response = requests.post(url, headers=_headers(xdata))
    return response.json()


# === API Functions: OTP ===
def request_otp(msisdn: str):
    command = "req-otp"
    signature = _generate_signature(command)
    payload = {
        "api_username": API_USERNAME,
        "api_key": API_KEY,
        "msisdn": msisdn,
        "command": command,
        "signature": signature
    }
    xdata = _encrypt(payload, API_KEY)
    url = f"{BASE_URL}/Docs/XL/V2/req-otp"
    response = requests.post(url, headers=_headers(xdata))
    return response.json()

def verify_otp(msisdn: str, otp_code: str):
    command = "ver-otp"
    signature = _generate_signature(command)
    payload = {
        "api_username": API_USERNAME,
        "api_key": API_KEY,
        "msisdn": msisdn,
        "otp": otp_code,
        "command": command,
        "signature": signature
    }
    xdata = _encrypt(payload, API_KEY)
    url = f"{BASE_URL}/Docs/XL/V2/ver-otp"
    response = requests.post(url, headers=_headers(xdata))
    return response.json()
