from kyt import *

import os
import subprocess
import asyncio
import time
import math
import re
from telethon import events, Button
from asyncio import Lock

ssh_lock = Lock()
# Constants
SESSION_TIMEOUT = 120     # detik sebelum sesi dianggap timeout
PER_PAGE        = 30      # jumlah user per halaman

# Konfigurasi aksi SSH
SSH_ACTIONS = {
    "delete-ssh": {
        "list_cmd":    "grep '^###' /etc/xray/ssh | cut -d ' ' -f 2-3",
        "exec_code":   "4",
        "success_msg": "User SSH berhasil dihapus."
    },
    "login-ssh": {
        "list_cmd":    "grep '^###' /etc/xray/sshx/listlock | cut -d ' ' -f 2-3",
        "exec_code":   "9",
        "success_msg": "User berhasil di-unlock."
    },
    "akun-ssh": {
        "list_cmd":    "grep '^###' /etc/xray/ssh | cut -d ' ' -f 2-3",
        "exec_code":   "6",
        "success_msg": "Cek akun berhasil dijalankan."
    },
    "limit-ssh": {
        "list_cmd":     "grep '^###' /etc/xray/ssh | cut -d ' ' -f 2-3",
        "exec_code":    "7",
        "extra_prompt": "Ketik Limit IP Login Baru:",
        "success_msg":  "Limit IP berhasil diubah."
    }
}

# ====== State Management ======
def start_session(bot, chat_id, sender_id, users, action):
    """Inisialisasi sesi interaktif untuk chat_id tertentu."""
    bot._ssh_state = getattr(bot, "_ssh_state", {})
    bot._ssh_state[chat_id] = {
        "users":         users,
        "sender_id":     sender_id,
        "action":        action,
        "page":          1,
        "stage":         0,          # 0 = pilih user, 1 = input tambahan (limit-ssh)
        "last_activity": time.time()
    }

def get_session(bot, chat_id):
    return getattr(bot, "_ssh_state", {}).get(chat_id)

def update_activity(state):
    state["last_activity"] = time.time()

def clear_session(bot, chat_id):
    bot._ssh_state.pop(chat_id, None)

def check_timeout(bot, chat_id):
    state = get_session(bot, chat_id)
    if not state:
        return True
    if time.time() - state["last_activity"] > SESSION_TIMEOUT:
        clear_session(bot, chat_id)
        return True
    return False

# ====== Pagination Builder ======
def build_pagination(users, page=1, per_page=PER_PAGE, action_prefix=""):
    total = len(users)
    start = (page - 1) * per_page
    end   = min(start + per_page, total)
    lines = [f"{i+1}) {users[i]}" for i in range(start, end)]

    # Teks tampilan
    text = (
        f"**{action_prefix.replace('-', ' ').upper()} (Hal {page}/{math.ceil(total/per_page)})**\n"
        + "\n".join(lines)
        + "\n\nPilih nomor user:"
    )

    # Tombol navigasi
    buttons = []
    nav = []
    if page > 1:
        nav.append(
            Button.inline("‹ Prev", f"{action_prefix}-page-{page-1}".encode())
        )
    if end < total:
        nav.append(
            Button.inline("Next ›", f"{action_prefix}-page-{page+1}".encode())
        )
    if nav:
        buttons.append(nav)

    # Tombol batal
    buttons.append([Button.inline("Cancel", b"menu")])
    return text, buttons


def user_exists(username):
    """Cek apakah username ada di file SSH."""
    if not os.path.exists("/etc/xray/ssh"):
        return False
    try:
        result = safe_exec(f'grep -w "### {username}" /etc/xray/ssh')
        return bool(result)
    except Exception:
        return False


#====== CREATE SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    sender = await event.get_sender()
    user_id = sender.id

    async with bot.conversation(user_id) as conv:  # Per-user conversation
        await event.edit(
            "**Masukkan data akun dalam format:**\n"
            "`username password expired limit_ip`\n\n"
            "**Contoh:** `andi pass123 30 2`",
            buttons=[[Button.inline("Cancel", b"menu")]]
        )

        try:
            msg = await conv.wait_event(
                events.NewMessage(incoming=True, from_users=user_id),
                timeout=60
            )
        except asyncio.TimeoutError:
            return await event.respond(
                "Waktu habis.",
                buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
            )

        parts = msg.raw_text.strip().split()

        # Validasi jumlah argumen
        if len(parts) != 4:
            return await event.respond(
                "Format input salah. Gunakan format: `username password expired limit_ip`",
                buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
            )

        username, password, exp, limit_ip = parts

        # Validasi username
        if " " in username:
            return await event.respond(
                "Username tidak boleh mengandung spasi.",
                buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
            )
        if user_exists(username):
            return await event.respond(
                "Username sudah ada.",
                buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
            )

        # Validasi angka
        if not exp.isdigit() or not limit_ip.isdigit():
            return await event.respond(
                "Expired dan Limit IP harus berupa angka.",
                buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
            )

        # Eksekusi pembuatan akun dengan lock
        async with ssh_lock:
            safe_exec(
                f'printf "%s\n" "1" "{username}" "{password}" "{exp}" "{limit_ip}" | m-sshovpn'
            )

    await event.respond(
        "Akun SSH berhasil dibuat.",
        buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
    )


# TRIAL SSH
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    chat = event.chat_id
    sender = await event.get_sender()

    async with bot.conversation(chat) as conv:
        await event.edit("**Masukan Menit (Hanya angka) :**", buttons=[[Button.inline("Cancel", b"menu")]])
        minutes_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
        minutes = minutes_msg.raw_text.strip()

        safe_exec(f'printf "%s\n" "2" "{minutes}" | m-sshovpn')

    await event.respond("Trial SSH berhasil dibuat.", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])


#====== RENEW SSH
@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    chat_id = event.chat_id
    sender = await event.get_sender()

    raw_users = safe_exec("grep '^###' /etc/xray/ssh | cut -d ' ' -f 2-3")
    if not raw_users or raw_users.strip() == "-":
        return await event.respond(
            "Tidak ada user SSH.",
            buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
        )

    users = raw_users.strip().split("\n")
    total_users = len(users)

    def get_page(page=1, per_page=30):
        start = (page - 1) * per_page
        end = start + per_page
        page_users = users[start:end]
        list_text = "\n".join([f"{i+1+start}) {u}" for i, u in enumerate(page_users)])

        buttons = []
        nav_buttons = []
        if page > 1:
            nav_buttons.append(Button.inline("‹ Prev", f"renew-ssh-page-{page-1}".encode()))
        if end < total_users:
            nav_buttons.append(Button.inline("Next ›", f"renew-ssh-page-{page+1}".encode()))
        if nav_buttons:
            buttons.append(nav_buttons)

        buttons.append([Button.inline("Cancel", b"menu")])
        return f"**LIST RENEW USER (Halaman {page})**\n{list_text}\n\nPilih nomor user:", buttons

    text, buttons = get_page(1)
    await event.edit(text, buttons=buttons)

    bot._renew_state = bot.__dict__.get("_renew_state", {})
    bot._renew_state[chat_id] = {
        "page": 1,
        "users": users,
        "sender_id": sender.id,
        "last_activity": time.time()
    }


@bot.on(events.CallbackQuery(pattern=b'renew-ssh-page-(\\d+)'))
async def renew_ssh_page(event):
    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    chat_id = event.chat_id
    page = int(event.pattern_match.group(1))

    state = bot._renew_state.get(chat_id)
    if not state:
        return await event.answer("Sesi tidak ditemukan.", alert=True)

    if time.time() - state["last_activity"] > SESSION_TIMEOUT:
        bot._renew_state.pop(chat_id, None)
        return await event.edit("Sesi telah berakhir karena timeout.", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

    users = state["users"]
    total_users = len(users)

    def get_page(page=1, per_page=30):
        start = (page - 1) * per_page
        end = start + per_page
        page_users = users[start:end]
        list_text = "\n".join([f"{i+1+start}) {u}" for i, u in enumerate(page_users)])

        buttons = []
        nav_buttons = []
        if page > 1:
            nav_buttons.append(Button.inline("‹ Prev", f"renew-ssh-page-{page-1}".encode()))
        if end < total_users:
            nav_buttons.append(Button.inline("Next ›", f"renew-ssh-page-{page+1}".encode()))
        if nav_buttons:
            buttons.append(nav_buttons)

        buttons.append([Button.inline("Cancel", b"menu")])
        return f"**LIST RENEW USER (Halaman {page})**\n{list_text}\n\nPilih nomor user:", buttons

    text, buttons = get_page(page)
    state["page"] = page
    state["last_activity"] = time.time()
    await event.edit(text, buttons=buttons)


@bot.on(events.NewMessage)
async def renew_ssh_input(event):
    chat_id = event.chat_id
    state = bot._renew_state.get(chat_id)
    if not state or event.sender_id != state["sender_id"]:
        return

    if time.time() - state["last_activity"] > SESSION_TIMEOUT:
        bot._renew_state.pop(chat_id, None)
        return await event.respond("Sesi telah berakhir karena timeout.", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

    state["last_activity"] = time.time()

    if "selected_num" not in state:
        num = event.raw_text.strip()
        if not num.isdigit():
            return await event.respond("Nomor tidak valid. Silakan masukkan nomor yang benar.")
        state["selected_num"] = num
        await event.respond("Ketik expired baru (hari):", buttons=[[Button.inline("Cancel", b"menu")]])
        return

    exp = event.raw_text.strip()
    if not exp.isdigit():
        return await event.respond("Expired tidak valid. Masukkan angka hari yang benar.")

    safe_exec(f'printf "%s\n" "3" "{state["selected_num"]}" "{exp}" | m-sshovpn')
    await event.respond("Perpanjangan berhasil.", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])
    bot._renew_state.pop(chat_id, None)


# ====== Handler Utama: Mulai Aksi SSH ======
@bot.on(events.CallbackQuery(pattern=b'(delete-ssh|login-ssh|akun-ssh|limit-ssh)$'))
async def ssh_action_handler(event):
    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    action = event.pattern_match.group(1).decode()
    cfg    = SSH_ACTIONS[action]
    sender = await event.get_sender()

    raw = safe_exec(cfg["list_cmd"])
    if not raw or not raw.strip() or raw.strip() == "-":
        return await event.respond(
            "Tidak ada user.",
            buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
        )

    users = raw.strip().splitlines()
    start_session(bot, event.chat_id, sender.id, users, action)
    text, buttons = build_pagination(users, page=1, per_page=PER_PAGE, action_prefix=action)
    await event.edit(text, buttons=buttons)

# ====== Handler Pagination ======
@bot.on(events.CallbackQuery(pattern=b'(delete-ssh|login-ssh|akun-ssh|limit-ssh)-page-(\d+)'))
async def ssh_pagination_handler(event):
    if check_timeout(bot, event.chat_id):
        return await event.edit(
            "Sesi berakhir.",
            buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
        )

    state = get_session(bot, event.chat_id)
    if not state:
        return await event.edit(
            "Sesi tidak ditemukan.",
            buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
        )

    page = int(event.pattern_match.group(2))
    state["page"] = page
    update_activity(state)

    text, buttons = build_pagination(
        state["users"],
        page=page,
        per_page=PER_PAGE,
        action_prefix=state["action"]
    )
    await event.edit(text, buttons=buttons)

# ====== Handler Input Nomor User & Limit ======
@bot.on(events.NewMessage(incoming=True))
async def ssh_input_handler(event):
    state = get_session(bot, event.chat_id)
    if not state or event.sender_id != state["sender_id"]:
        return

    if check_timeout(bot, event.chat_id):
        return await event.respond(
            "Sesi berakhir.",
            buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
        )

    update_activity(state)
    text = event.raw_text.strip()
    action_cfg = SSH_ACTIONS[state["action"]]

    # Stage 0: pilih nomor user
    if state["stage"] == 0:
        if not text.isdigit():
            return await event.respond("Nomor tidak valid. Masukkan angka yang benar.")

        idx = int(text)
        if idx < 1 or idx > len(state["users"]):
            return await event.respond(f"Nomor harus antara 1 dan {len(state['users'])}.")

        state["selected_num"] = idx

        # Jika limit-ssh: minta input tambahan
        if state["action"] == "limit-ssh":
            state["stage"] = 1
            return await event.respond(
                action_cfg["extra_prompt"],
                buttons=[[Button.inline("Cancel", b"menu")]]
            )

        # Aksi tanpa input tambahan
        safe_exec(f'printf "%s\n" "{action_cfg["exec_code"]}" "{idx}" | m-sshovpn')
        clear_session(bot, event.chat_id)
        return await event.respond(
            action_cfg["success_msg"],
            buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
        )

    # Stage 1: input limit IP for limit-ssh
    if state["stage"] == 1:
        if not text.isdigit() or int(text) < 1:
            return await event.respond("Limit IP harus angka > 0.")

        limit_ip = text
        idx      = state["selected_num"]
        safe_exec(
            f'printf "%s\n" "{action_cfg["exec_code"]}" "{idx}" "{limit_ip}" | m-sshovpn'
        )

        clear_session(bot, event.chat_id)
        return await event.respond(
            action_cfg["success_msg"],
            buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
        )


@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    # Cek akses
    if not await check_access(event):
        return await event.answer("Access Denied", alert=True)

    # Susunan tombol menu SSH
    inline_buttons = [
        [
            Button.inline("Trial", b"trial-ssh"),
            Button.inline("Create", b"create-ssh")
        ],
        [
            Button.inline("Delete", b"delete-ssh"),
            Button.inline("Unlock", b"login-ssh"),
            Button.inline("Limit", b"limit-ssh")
        ],
        [
            Button.inline("Renew", b"renew-ssh"),
            Button.inline("Akun", b"akun-ssh"),
            Button.inline("⟨ MENU ⟩", b"menu")
        ]
    ]

    # Ambil informasi server
    ip_addr   = safe_file("/etc/myipvps")
    domainz   = safe_file("/etc/xray/domain")
    isp       = safe_file("/etc/xray/isp")
    city      = safe_file("/etc/xray/city")
    profil    = safe_file("/etc/profil")
    time_info = safe_exec("LC_TIME=id_ID.UTF-8 date '+%A, %d %B %Y - %H:%M WIB'")

    # Pesan informasi panel
    msg = (
        "━━━━━━━━━━━━━━━━━━━━\n"
        "**PANEL XIESTORE**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"**IP :** {ip_addr}\n"
        f"**Domain :** {domainz}\n"
        f"**ISP :** {isp}\n"
        f"**Kota :** {city}\n"
        f"**Profil :** {profil}\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"__{time_info}__"
    )

    # Tampilkan menu
    await event.edit(msg, buttons=inline_buttons)
