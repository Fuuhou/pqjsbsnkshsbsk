from kyt import *

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    async def collect_data():
        chat = event.chat_id
        sender = await event.get_sender()
        user_id = sender.id
        
        # Step 1: Get username
        async with bot.conversation(chat) as conv:
            await conv.send_message(
                "**BUAT USERNAME TANPA SPASI**\n/cancel Untuk Kembali",
                buttons=Button.force_reply()
            )
            user_reply = await conv.get_response()
            if user_reply.text == '/cancel':
                await event.respond("**» CANCEL**", buttons=[[Button.inline("‹ Main Menu ›","menu")]])
                return

            username = user_reply.text.strip()
            
            # Step 2: Get password
            await conv.send_message("**KETIK PASSWORD AKUN :**", buttons=Button.force_reply())
            pw_reply = await conv.get_response()
            password = pw_reply.text.strip()
            
            # Step 3: Get expiration
            await conv.send_message("**KETIK EXP AKUN (Day) :**", buttons=Button.force_reply())
            exp_reply = await conv.get_response()
            exp_days = exp_reply.text.strip()
            
            # Step 4: Get limit IP
            await conv.send_message("**KETIK LIMIT IP LOGIN :**", buttons=Button.force_reply())
            limit_reply = await conv.get_response()
            ip_limit = limit_reply.text.strip()

        return {
            'username': username,
            'password': password,
            'exp_days': exp_days,
            'ip_limit': ip_limit,
            'user_id': user_id,
            'event': event
        }

    # Add task to queue
    task = asyncio.create_task(process_ssh_creation(await collect_data()))
    await task_queue.put(task)
    await event.respond("🔄 Permintaan Anda telah masuk dalam antrian. Silakan tunggu...")

async def process_ssh_creation(data):
    try:
        event = data['event']
        user_id = data['user_id']
        
        # Hitung biaya dan proses pembayaran
        stock_data = load_data_from_github(STOCK_PATH)
        price_per_day = get_price_for_server_and_label(IPVPS, "Non-STB")
        pay_coin = int(data['exp_days']) * price_per_day
        
        user_data = load_data_from_github(FILE_PATH)
        user_info = user_data.get(user_id, {})
        
        # Cukup saldo?
        if user_info.get('coin', 0) < pay_coin:
            await event.respond("❌ Saldo tidak mencukupi!")
            return

        # Kurangi saldo
        user_info['coin'] -= pay_coin
        user_info['coin_usage'] = user_info.get('coin_usage', 0) + pay_coin
        save_data_to_github(FILE_PATH, user_data, "Pengurangan coin sebelum eksekusi curl")

        # Proses pembuatan SSH
        cmd = f'printf "%s\n" "1" "{data["username"]}" "{data["password"]}" "{data["exp_days"]}" "{data["ip_limit"]}" | m-sshovpn'
        process = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        
        if process.returncode != 0:
            raise Exception(f"Error creating SSH: {stderr.decode()}")

        # Update stok
        stock_data = load_data_from_github(STOCK_PATH)
        if stock_data.get(IPVPS, {}).get('stock_vpn', 0) > 0:
            stock_data[IPVPS]['stock_vpn'] -= 1
            save_data_to_github(STOCK_PATH, stock_data, "Update stok VPN")

        await event.respond(f"""
✅ Akun SSH Berhasil Dibuat!
Username: {data['username']}
Password: {data['password']}
Masa Aktif: {data['exp_days']} Hari
Limit IP: {data['ip_limit']}
""")

    except Exception as e:
        logging.error(f"Error processing SSH creation: {str(e)}")
        # Rollback coin jika error
        if 'pay_coin' in locals():
            user_info['coin'] += pay_coin
            user_info['coin_usage'] -= pay_coin
            save_data_to_github(FILE_PATH, user_data, "Rollback coin karena error")
        await event.respond(f"❌ Gagal membuat akun SSH: {str(e)}")


@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LIST ALL USER**
{z}
**KETIK NOMOR :**
/cancel Untuk Kembali
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "4" "{user}" | m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'limit-ssh'))
async def limit_ssh(event):
	async def limit_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**CHANGE LIMIT USER**
{z}
**KETIK NOMOR :**
/cancel Untuk Kembali
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**Ketik Limit IP Login Baru :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "7" "{user}" "{exp}" | m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES Delete**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		async with bot.conversation(chat) as exp:
			await event.edit(f"""
**Masukan Menit (Hanya angka) :**
/cancel Untuk Kembali
""")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		per = "/cancel"
		if exp == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" {2} "{exp}" | m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'cek-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'bot-cek-login-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit(f"""
** SSH USER ONLINE**
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
	async def renew_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LIST RENEW USER**
{z}
**MASUKAN NOMOR :**
/cancel Untuk Kembali
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""
**KETIK EXPIRED BARU (day) :**
""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "3" "{user}" "{exp}" | m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/sshx/listlock | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**LIST MULTI LOGIN USER**
{z}
**KETIK NOMOR :**
/cancel Untuk Kembali
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "9" "{user}" | m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES UNLOCK**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'akun-ssh'))
async def akun_ssh(event):
	async def akun_ssh_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/ssh | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			print(x)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
**CEK CONFIG USER**
{z}
**KETIK NOMOR :**
/cancel Untuk Kembali
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			cmd = f'printf "%s\n" "6" "{user}" | m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CEK AKUN**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akun_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" Trial ","trial-ssh"),
Button.inline(" Create ","create-ssh"),
Button.inline(" Login ","cek-ssh")],
[Button.inline(" Delete ","delete-ssh"),
Button.inline(" Unlock ","login-ssh"),
Button.inline(" Limit ","limit-ssh")],
[Button.inline(" Renew","renew-ssh"),
Button.inline(" Akun ","akun-ssh"),
Button.inline("‹ BACK ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/xray/ssh | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		msg = f"""
───────────────────
**⚡PANEL MENU SSH⚡**
───────────────────
`🔰 Total   :` `{ssh.strip()}` __account__
`🔰 Host    :` `{DOMAIN}`
`🔰 ISP     :` `{z["isp"]}`
`🔰 Country :` `{z["country"]}`
───────────────────
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)