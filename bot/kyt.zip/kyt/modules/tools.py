from kyt import *
from telethon import TelegramClient, events
from telethon.tl.types import ChatBannedRights, InputPeerUser, PeerUser
from telethon.tl.functions.channels import EditBannedRequest
from telethon.tl.functions.messages import SendDocumentRequest

from github import Github, GithubException
from datetime import datetime, timedelta
from collections import defaultdict, deque
from dotenv import load_dotenv
from apscheduler.schedulers.background import BackgroundScheduler
from calendar import month_name
from urllib.parse import urlparse, parse_qs
import tempfile
import subprocess
import base64
import re
import os
import json
import schedule
import requests
import time
import logging
import random
import string
import pickle
import threading
import shlex
import pytz
import yaml

# Load environment variables from .env file
env_path = "/usr/bin/kyt/config.env"
if os.path.exists(env_path):
    load_dotenv(env_path)
else:
    print("⚠️  File config.env tidak ditemukan!")


# Configuration and global variables
#TOKEN_BOT = os.getenv("TOKEN_BOT")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
ADMINS_FILE_PATH = os.getenv("ADMINS_FILE_PATH")
FILE_PATH = os.getenv("FILE_PATH")
USER_DATA_PATH = os.getenv("USER_DATA_PATH")
SERVER_PATH = os.getenv("SERVER_PATH")
GIFT_CODES_FILE = os.getenv("GIFT_CODES_FILE")
NOTIF_PATH = os.getenv("NOTIF_PATH")
STOCK_PATH = os.getenv("STOCK_PATH")
TRX_PATH = os.getenv("TRX_PATH")
BLOCK_SPAM = os.getenv("BLOCK_SPAM")
BLOCKED_USERS_PATH = os.getenv("BLOCKED_USERS_PATH")
LAST_TRIAL_FILE = os.getenv("LAST_TRIAL_FILE")
AKUN_VPN_PATH = os.getenv("AKUN_VPN_PATH")
PRICE_PATH = os.getenv("PRICE_PATH")
USAGE_PATH = os.getenv("USAGE_PATH")
POST_PATH = os.getenv("POST_PATH")
PROFIL_PATH = os.getenv("PROFIL_PATH")
HOST_FILE_PATH = os.getenv("HOST_FILE_PATH")
CHAT_ID = os.getenv("CHAT_ID")
CHAT_ID_BACKUP = os.getenv("CHAT_ID_BACKUP")
LOGGING_API_URL = f'https://api.telegram.org/bot{TOKEN_BOT}/sendMessage'
REPO_NAME = os.getenv("REPO_NAME")
BACKUP_URL = os.getenv("BACKUP_URL")
NOTIF_CONFIG_FILE = "notif_config.json"

# Initialize GitHub connection
g = Github(GITHUB_TOKEN)
repo = g.get_repo(REPO_NAME)

# Global variable
last_update = None
last_context = None
auto_delete_timer = None
os.environ['TZ'] = 'Asia/Jakarta'

# Setup logging
logging.basicConfig(filename='log_coin.txt', level=logging.INFO, format='%(asctime)s - %(message)s')

# Dictionary to store the timestamps of user messages
user_message_timestamps = defaultdict(deque)

GITHUB_RAW_URL = "https://raw.githubusercontent.com/Fuuhou/tes/refs/heads/main/users.txt"
# Inisialisasi task queue dan worker
task_queue = asyncio.Queue()
worker_count = 3  # Jumlah worker paralel
# Cache harga
price_cache = {
    "data": None,
    "timestamp": None
}
CACHE_TTL = timedelta(minutes=60) 

async def worker(name):
    while True:
        task = await task_queue.get()
        try:
            await task
        except Exception as e:
            logging.error(f"Error in worker {name}: {str(e)}")
        finally:
            task_queue.task_done()

# Start workers
for i in range(worker_count):
    asyncio.create_task(worker(f"worker-{i+1}"))


def load_user_ids_from_github(url):
    """Mengambil daftar user ID dari file .txt di GitHub (berisi 10 user ID per baris)."""
    try:
        response = requests.get(url)
        response.raise_for_status()  # Akan memunculkan error jika request gagal
        lines = response.text.splitlines()  # Memisahkan setiap baris

        user_ids = []
        for line in lines:
            # Pisahkan berdasarkan spasi, koma, atau tab
            ids = line.replace(',', ' ').split()
            # Ambil hanya angka dan pastikan dalam bentuk string
            user_ids.extend([uid.strip() for uid in ids if uid.strip().isdigit()])

        return user_ids  # Mengembalikan daftar user ID
    except requests.RequestException as e:
        logging.error(f"Error saat mengambil user ID dari GitHub: {e}")
        return []

def commit_and_push_to_github(file_path, commit_message):
    """Menggunakan GitHub API untuk commit dan push file ke repository."""
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            file_data = file.read()

        file_name = os.path.basename(file_path)

        # Cek apakah file sudah ada di repo
        contents = repo.get_contents(file_name)
        repo.update_file(contents.path, commit_message, file_data, contents.sha)
        logging.info(f"File {file_name} successfully updated on GitHub with commit message: {commit_message}")
    except GithubException:
        # Jika file tidak ada, buat baru
        repo.create_file(file_name, commit_message, file_data)
        logging.info(f"File {file_name} successfully created on GitHub with commit message: {commit_message}")
    except Exception as e:
        logging.error(f"Error during GitHub push: {str(e)}")

def load_text_data_from_github(file_name):
    """Mengambil isi file teks dari GitHub."""
    try:
        contents = repo.get_contents(file_name)
        return contents.decoded_content.decode()  # Kembalikan isi file sebagai teks
    except Exception as e:
        logging.error(f"Error loading text data from GitHub ({file_name}): {e}")
        return ""

def save_text_data_to_github(file_name, data, commit_message):
    """Menyimpan teks ke file di GitHub."""
    try:
        contents = repo.get_contents(file_name)
        repo.update_file(contents.path, commit_message, data, contents.sha)
        logging.info(f"Text data in {file_name} successfully updated on GitHub.")
    except Exception as e:
        logging.error(f"Error updating text data on GitHub ({file_name}): {e}")

async def check_spam(event):
    """Cek apakah user melakukan spam dan blokir jika perlu."""
    user_id = event.sender_id
    current_time = time.time()

    # Tambahkan timestamp pesan user
    user_message_timestamps[user_id].append(current_time)

    # Hapus timestamp yang lebih dari 30 detik
    while user_message_timestamps[user_id] and user_message_timestamps[user_id][0] < current_time - 30:
        user_message_timestamps[user_id].popleft()

    # Jika user mengirim lebih dari 100 pesan dalam 30 detik, blokir
    if len(user_message_timestamps[user_id]) >= 100:
        try:
            # Blokir user di grup selama 5 jam
            ban_rights = ChatBannedRights(until_date=current_time + 18000, send_messages=True)
            await client(EditBannedRequest(event.chat_id, user_id, ban_rights))

            await event.reply(f"User `{user_id}` diblokir karena spamming. Auto-unblock dalam 5 jam.", parse_mode="md")
            user_message_timestamps[user_id] = deque()  # Reset timestamps setelah blokir

            # Simpan data user yang diblokir ke file JSON
            blocked_user_data = {"user_id": user_id, "block_time": current_time}
            with open(BLOCK_SPAM, "a") as file:
                json.dump(blocked_user_data, file)
                file.write("\n")

            commit_and_push_to_github(BLOCK_SPAM, f"Block user `{user_id}` for spamming")

            # Kirim notifikasi ke channel/grup
            await client.send_message(CHAT_ID, f"User `{user_id}` diblokir karena spamming.", parse_mode="md")

        except Exception as e:
            logging.error(f"Error banning user {user_id}: {e}")

# Event listener untuk semua pesan masuk
@bot.on(events.NewMessage)
async def handle_check_message(event):
    await check_spam(event)

def load_data_from_github(file_name, branch="main"):
    """
    Mengambil konten file dari GitHub dan mengembalikannya dalam bentuk objek Python.
    Jika file tidak ditemukan atau terjadi error, akan mengembalikan dict kosong.
    """
    try:
        contents = repo.get_contents(file_name, ref=branch)
        data = json.loads(contents.decoded_content.decode())
        logging.info(f"Data dari '{file_name}' berhasil dimuat dari GitHub.")
        return data
    except GithubException as e:
        if e.status == 404:
            logging.warning(f"File '{file_name}' tidak ditemukan di GitHub. Mengembalikan data kosong.")
        else:
            logging.error(f"Error mengambil file '{file_name}' dari GitHub: {e}")
        return {}
    except Exception as e:
        logging.error(f"Error tidak terduga saat memuat '{file_name}': {e}")
        return {}

def save_data_to_github(file_name, data, commit_message, branch="main"):
    """
    Mengubah (update) file yang ada di GitHub dengan data baru.
    Jika file tidak ditemukan (404), maka file baru akan dibuat.
    """
    updated_content = json.dumps(data, indent=4)
    try:
        # Coba ambil file terlebih dahulu
        contents = repo.get_contents(file_name, ref=branch)
        # Jika file ada, lakukan update
        repo.update_file(contents.path, commit_message, updated_content, contents.sha, branch=branch)
        logging.info(f"Data pada '{file_name}' berhasil di-update di GitHub.")
    except GithubException as e:
        if e.status == 404:
            try:
                # File tidak ada, buat file baru
                repo.create_file(file_name, commit_message, updated_content, branch=branch)
                logging.info(f"File '{file_name}' tidak ditemukan, sehingga dibuat baru di GitHub.")
            except Exception as create_error:
                logging.error(f"Error saat membuat file '{file_name}' di GitHub: {create_error}")
        else:
            logging.error(f"Error saat meng-update file '{file_name}' di GitHub: {e}")
    except Exception as e:
        logging.error(f"Error tidak terduga saat menyimpan data ke '{file_name}': {e}")

async def save_data_to_github_append(file_name, new_data, commit_message, branch="main"):
    """
    Menambahkan data baru ke file JSON di GitHub tanpa menghapus data lama.
    Jika file belum ada, maka akan dibuat baru.
    """
    try:
        contents = repo.get_contents(file_name, ref=branch)
        existing_data = json.loads(contents.decoded_content.decode())

        if not isinstance(existing_data, list):
            logging.error(f"Format data di '{file_name}' tidak sesuai (bukan list).")
            return False

        existing_data.append(new_data)
        updated_content = json.dumps(existing_data, indent=4)

        repo.update_file(contents.path, commit_message, updated_content, contents.sha, branch=branch)
        logging.info(f"Data baru berhasil ditambahkan ke '{file_name}' di GitHub.")
        return True

    except GithubException as e:
        if e.status == 404:
            try:
                new_content = json.dumps([new_data], indent=4)
                repo.create_file(file_name, commit_message, new_content, branch=branch)
                logging.info(f"File '{file_name}' tidak ditemukan. File baru dibuat dengan data pertama.")
                return True
            except Exception as create_error:
                logging.error(f"Error saat membuat file '{file_name}': {create_error}")
        else:
            logging.error(f"Error saat menambahkan data ke '{file_name}': {e}")
    except Exception as e:
        logging.error(f"Kesalahan tidak terduga saat menyimpan ke '{file_name}': {e}")

    return False

def load_user_data():
    """Memuat user ID dari file .txt dengan format 10 user ID per baris."""
    user_data = []

    if os.path.exists(USER_DATA_PATH):
        try:
            with open(USER_DATA_PATH, "r") as file:
                for line in file:
                    ids = line.strip().split()
                    user_data.extend([uid for uid in ids if uid.isdigit()])
        except Exception as e:
            logging.error(f"Error loading user data: {e}")

    return user_data

def save_user_data(user_data):
    """Menyimpan user ID dengan format 10 user ID per baris."""
    try:
        with open(USER_DATA_PATH, "w") as file:
            for i in range(0, len(user_data), 10):
                file.write(" ".join(user_data[i:i+10]) + "\n")
    except Exception as e:
        logging.error(f"Error saving user data: {e}")

def add_new_user(user_id):
    """Menambahkan user ID baru jika belum ada, dengan format 10 user ID per baris."""
    user_data = load_user_data()

    if str(user_id) not in user_data:
        user_data.append(str(user_id))
        save_user_data(user_data)
        logging.info(f"User ID {user_id} ditambahkan.")
    else:
        logging.info(f"User ID {user_id} sudah terdaftar.")

@bot.on(events.NewMessage(pattern="/start"))
async def handle_new_chat(event):
    """Menangani pengguna baru yang melakukan chat pribadi atau start bot."""
    user_id = str(event.sender_id)

    if event.is_private:
        add_new_user(user_id)
        await event.respond("Terima kasih telah menggunakan bot ini! User ID Anda telah disimpan.")

# Fungsi untuk mengirim notifikasi
async def send_notif(chat_id, message, topic_id=None, parse_mode="md"):
    """
    Mengirim notifikasi ke grup atau channel dengan dukungan `topic_id` (Thread ID).
    """
    try:
        if topic_id:
            await client.send_message(chat_id, message, parse_mode=parse_mode, reply_to=topic_id)
        else:
            await client.send_message(chat_id, message, parse_mode=parse_mode)
        logging.info(f"Notification sent to {chat_id} (Topic ID: {topic_id}): {message}")

        # Jika LOGGING_API_URL tersedia, kirim log ke endpoint eksternal
        if LOGGING_API_URL:
            payload = {
                "chat_id": chat_id,
                "text": message,
                "parse_mode": parse_mode,
                "topic_id": topic_id,
            }
            response = requests.post(LOGGING_API_URL, json=payload)
            response.raise_for_status()
    except Exception as e:
        logging.error(f"Failed to send notification: {e}")

# Fungsi untuk mencatat aksi dan mengirim notifikasi ke thread yang telah disimpan
async def record_and_notify(user_id, action_description):
    """
    Merekam aksi pengguna dan mengirim notifikasi ke thread yang telah disimpan.
    """
    timestamp = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    action_message = (
        f"**User ID :** `{user_id}`\n"
        f"**Date :** `{timestamp} WIB`\n"
        f"**Action :** `{action_description}`"
    )
    logging.info(action_message)

    # Ambil topic_id yang telah disimpan
    topic_id = load_notif_topic()

    await send_notif(CHAT_ID, action_message, topic_id=topic_id, parse_mode="md")

# Fungsi untuk menyimpan topic_id dari perintah /notif
def save_notif_topic(topic_id):
    """
    Menyimpan topic_id untuk digunakan dalam notifikasi selanjutnya.
    """
    try:
        with open(NOTIF_CONFIG_FILE, "w") as file:
            json.dump({"topic_id": topic_id}, file)
        logging.info(f"Topic ID {topic_id} berhasil disimpan untuk notifikasi.")
    except Exception as e:
        logging.error(f"Error saat menyimpan topic_id: {e}")

# Fungsi untuk memuat topic_id yang telah disimpan
def load_notif_topic():
    """
    Memuat topic_id yang telah disimpan.
    """
    try:
        if os.path.exists(NOTIF_CONFIG_FILE):
            with open(NOTIF_CONFIG_FILE, "r") as file:
                data = json.load(file)
                return data.get("topic_id")
    except Exception as e:
        logging.error(f"Error saat memuat topic_id: {e}")
    return None

# Event handler untuk perintah /notif
@bot.on(events.NewMessage(pattern=r"^/notif$", func=lambda e: e.is_group))
async def set_notif_topic(event):
    """
    Menyimpan topic_id dari perintah /notif di dalam grup.
    """
    if event.reply_to_msg_id:
        topic_id = event.reply_to_msg_id
        save_notif_topic(topic_id)
        await event.reply("✅ Notifikasi akan dikirim ke thread ini.")
    else:
        await event.reply("⚠️ Harap gunakan perintah ini di dalam thread agar bisa disimpan.")

# Fungsi untuk mengecek apakah user adalah admin
def check_admin_access(user_id):
    data = load_text_data_from_github(ADMINS_FILE_PATH)
    return str(user_id) in data

# Decorator untuk membatasi akses hanya kepada admin
def admin_only(func):
    @wraps(func)
    async def wrapper(event, *args, **kwargs):
        user_id = event.sender_id
        if check_admin_access(user_id):
            return await func(event, *args, **kwargs)
        else:
            await event.reply("🚫 Kamu tidak memiliki akses untuk menggunakan perintah ini.")
    return wrapper

# Fungsi untuk mengecek apakah user sudah terdaftar
def is_registered_user(user_id):
    data = load_text_data_from_github(FILE_PATH)
    return str(user_id) in data

# Decorator untuk membatasi akses hanya untuk pengguna yang terdaftar
def registered_user_only(func):
    @wraps(func)
    async def wrapper(event, *args, **kwargs):
        user_id = event.sender_id
        if is_registered_user(user_id):
            return await func(event, *args, **kwargs)
        else:
            await event.reply(
                "🚫 Maaf, kamu belum terdaftar sebagai pengguna bot ini.\n\n"
                "💰 Untuk bisa menggunakan semua fitur, silakan lakukan top-up coin terlebih dahulu.\n"
                "📞 Hubungi Admin untuk bantuan lebih lanjut:\n"
                "🗨️ *@superxiez*",
                parse_mode="md",
            )
    return wrapper

async def rollback_coin(user_data, pay_coin, data):
    """Mengembalikan coin pengguna jika transaksi gagal."""
    try:
        user_data["coin"] += pay_coin
        user_data["coin_usage"] -= pay_coin

        # Simpan perubahan ke GitHub
        await save_data_to_github(FILE_PATH, data, "Rollback user coin")

        logging.info(f"✅ Rollback berhasil: +{pay_coin} coin untuk {user_data['user_id']}")
    except Exception as e:
        logging.error(f"❌ Gagal rollback coin: {e}")

def get_price_for_server_and_label(ip_address: str, label: str) -> int:
    """
    Mengambil harga berdasarkan IP server dan label dengan mekanisme cache.

    :param ip_address: IP server yang digunakan.
    :param label: Label kategori server (misalnya "Non-STB").
    :return: Harga (int) atau 0 jika tidak ditemukan.
    """
    try:
        now = datetime.utcnow()

        # Cek apakah data cache masih valid
        if (
            price_cache["data"] is None or 
            price_cache["timestamp"] is None or 
            now - price_cache["timestamp"] > CACHE_TTL
        ):
            logging.info("Memuat ulang data harga dari GitHub...")
            price_cache["data"] = load_data_from_github(PRICE_PATH)
            price_cache["timestamp"] = now  # Update timestamp cache

        # Ambil data dari cache
        price_data = price_cache["data"]

        # Validasi struktur data harga
        if not isinstance(price_data, dict) or "servers" not in price_data:
            logging.warning("Data harga tidak valid atau tidak memiliki key 'servers'.")
            return 0

        # Ambil harga berdasarkan IP dan label
        return int(price_data.get("servers", {}).get(ip_address, {}).get(label, {}).get("price", 0))
    
    except Exception as e:
        logging.exception(f"Error saat mengambil harga untuk {ip_address} - {label}: {e}")
        return 0  # Default harga jika terjadi kesalahan

@bot.on(events.NewMessage(pattern=r"^/topup(\s\d+\s\d+)?$"))
async def topup_coin(event):
    """Fungsi untuk melakukan top-up coin kepada pengguna lain."""
    message = event.message.text.split()

    # Periksa format perintah
    if len(message) != 3:
        await event.reply("⚠️ Gunakan format: `/topup <user_id> <jumlah_coin>`", parse_mode="markdown")
        return

    target_user_id, coin_str = message[1], message[2]

    # Periksa apakah jumlah coin adalah angka
    if not coin_str.isdigit():
        await event.reply("⚠️ Jumlah coin harus berupa angka.")
        return

    coin = int(coin_str)
    user_id = str(event.sender_id)

    # Ambil data pengguna dari GitHub
    data = await load_data_from_github(FILE_PATH)

    # Jika user belum terdaftar, buat entri baru
    if target_user_id not in data:
        data[target_user_id] = {'coin': 0, 'join_date': datetime.now().strftime('%d-%m-%Y'), 'coin_usage': 0}

    # Tambahkan coin ke pengguna target
    data[target_user_id]['coin'] += coin

    # Simpan kembali ke GitHub
    await save_data_to_github(FILE_PATH, data, f"Top-up {coin} Coin ke {target_user_id}")

    # Buat pesan top-up
    topup_msg = (
        "━━━━━━━━━━━━━━━━━━\n"
        "  **✰** 𝗧𝗢𝗣 𝗨𝗣 **✰**\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"**⋗ Isi Coin :** `{coin}`\n"
        f"**⋗ User ID :** [{target_user_id}](tg://user?id={target_user_id})\n"
        f"**⋗ Total Coin :** `{data[target_user_id]['coin']}`\n"
        f"**⋗ Tanggal :** `{datetime.now().strftime('%d-%m-%Y %H:%M')} WIB`\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "🏬 *@xiestorez*"
    )

    # Kirim notifikasi ke pengguna dan log transaksi
    await record_and_notify(user_id, f"Top-up {coin} Coin ke {target_user_id}")
    await event.reply(topup_msg, parse_mode="markdown")
    await client.send_message(int(target_user_id), topup_msg, parse_mode="markdown")

@bot.on(events.NewMessage(pattern='/backup'))
async def backup_file():
    try:
        # Mendownload file backup
        response = requests.get(BACKUP_URL)
        if response.status_code == 200:
            # Format nama file
            current_datetime = datetime.now(pytz.timezone('Asia/Jakarta'))
            current_date = current_datetime.strftime('%d-%m-%Y')
            current_time = current_datetime.strftime('%H:%M:%S')
            file_name = f"zoybackup_{current_date}.zip"

            # Menyimpan file sementara
            with open(file_name, 'wb') as f:
                f.write(response.content)

            # Deskripsi untuk file backup
            description = (
                "━━━━━━━━━━━━━━━━━━\n"
                f"📂 *File Backup*\n"
                f"📅 *Tanggal :* `{current_date}`\n"
                f"🕒 *Jam :* `{current_time} WIB`\n"
                "━━━━━━━━━━━━━━━━━━"
            )

            # Mengirim file backup ke Telegram
            with open(file_name, 'rb') as f:
                await client.send_file(
                    CHAT_ID_BACKUP, 
                    file=f,
                    caption=description,
                    parse_mode='markdown'
                )
            logger.info('File berhasil didownload dan dikirim: %s', file_name)

            # Menunggu beberapa detik untuk memastikan file tidak sedang digunakan
            time.sleep(2)

            # Menghapus file setelah dikirim
            try:
                os.remove(file_name)
                logger.info('File sementara telah dihapus: %s', file_name)
            except Exception as e:
                logger.error(f'Gagal menghapus file: {file_name}, Error: {e}')
        else:
            logger.error('Gagal mendownload file: %s', response.status_code)
    except Exception as e:
        logger.error('Terjadi kesalahan: %s', e)


async def share_message(event):
    user_id = str(event.sender_id)  # ID dari pengirim perintah
    message = event.message

    # Memastikan perintah digunakan dengan membalas pesan
    if not message.reply_to_msg_id:
        await event.respond("Gunakan perintah ini dengan membalas pesan yang ingin dibagikan.")
        return

    # Memuat daftar user ID dari GitHub
    user_ids = load_user_ids_from_github(ALL_USER_IDS_PATH)
    if not user_ids:
        await event.respond("Gagal memuat daftar user ID dari GitHub atau daftar kosong.")
        return

    success_count = 0
    failed_count = 0

    # Mengirim pesan ke setiap user ID
    for target_user_id in user_ids:
        try:
            # Menggunakan Telethon untuk forward pesan
            await client.forward_messages(
                int(target_user_id),  # Pastikan user ID dalam bentuk integer
                message.peer_id,  # ID chat asal pesan
                message.reply_to_msg_id  # ID pesan yang dibalas
            )
            success_count += 1
        except Exception as e:
            logging.warning(f"Gagal mengirim pesan ke {target_user_id}: {e}")
            failed_count += 1

    # Memberikan laporan hasil pengiriman
    await event.respond(
        f"Pesan berhasil dikirim ke {success_count} user.\n"
        f"Gagal mengirim pesan ke {failed_count} user."
    )

@bot.on(events.NewMessage(pattern=r'/trx\s+(\S+)\s+(\d{1,2})\s+(\d{4})'))
async def display_transactions(event):
    try:
        args = event.pattern_match.groups()
        server_name = args[0].lower()  # Server yang diminta

        try:
            month = int(args[1])  # Bulan dalam angka (misal: 12 untuk Desember)
            if not 1 <= month <= 12:
                await event.respond(f"Bulan {month} tidak valid! Harus antara 1 dan 12.")
                return
        except ValueError:
            await event.respond(f"Bulan {args[1]} tidak valid! Harus berupa angka.")
            return
        
        try:
            year = int(args[2])  # Tahun (misal: 2024)
        except ValueError:
            await event.respond(f"Tahun {args[2]} tidak valid! Harus berupa angka.")
            return

        # Load data transaksi dari file GitHub
        trx_data = load_text_data_from_github(TRX_PATH)

        if not trx_data.strip():
            await event.respond("Tidak ada transaksi yang tercatat.")
            return

        # Struktur data untuk menyimpan transaksi
        transactions_by_date = defaultdict(list)

        # Parsing data dari format file
        current_server = None
        for line in trx_data.splitlines():
            line = line.strip()
            if line.endswith("["):
                current_server = line[:-1].strip()
            elif line == "]":
                current_server = None
            elif current_server:
                try:
                    user_id, vpn_type, label, total_coin, timestamp = line.split(maxsplit=4)
                    timestamp = datetime.strptime(timestamp, '%d-%m-%Y %H:%M')
                    transactions_by_date[current_server].append({
                        "user_id": user_id,
                        "vpn_type": vpn_type,
                        "label": label,
                        "total_coin": int(total_coin),
                        "timestamp": timestamp
                    })
                except Exception as e:
                    logging.warning(f"Error parsing line: {line}, Error: {e}")

        # Filter data berdasarkan bulan, tahun, dan server
        filtered_transactions = defaultdict(list)
        for server, records in transactions_by_date.items():
            if server.lower() == server_name:
                for record in records:
                    if record["timestamp"].year == year and record["timestamp"].month == month:
                        filtered_transactions[server].append(record)

        # Menampilkan hasil
        if not filtered_transactions:
            await event.respond("Tidak ada transaksi yang ditemukan untuk filter yang diberikan.")
            return

        # Generate nama file dengan format `rekap_{tanggal}.txt`
        current_datetime = datetime.now(pytz.timezone('Asia/Jakarta'))
        current_date = current_datetime.strftime('%d-%m-%Y')
        file_name = f"rekap_{current_date}.txt"

        # Buat file sementara
        with open(file_name, 'w') as temp_file:
            temp_file.write("=" * 40 + "\n")
            temp_file.write("          REKAP TRANSAKSI VPN           \n")
            temp_file.write("=" * 40 + "\n")
            temp_file.write(f"Server       : {server_name.upper()}\n")
            temp_file.write(f"Periode      : {month_name[month]} {year}\n")
            temp_file.write("-" * 40 + "\n")
            
            total_transactions = 0
            total_coins = 0
            for server, records in filtered_transactions.items():
                for record in records:
                    temp_file.write("-" * 40 + "\n")
                    temp_file.write(f"Server      : {server}\n")
                    temp_file.write(f"User ID     : {record['user_id']}\n")
                    temp_file.write(f"Tipe VPN    : {record['vpn_type']}\n")
                    temp_file.write(f"Label       : {record['label']}\n")
                    temp_file.write(f"Coin        : {record['total_coin']}\n")
                    temp_file.write(f"Tanggal     : {record['timestamp'].strftime('%d-%m-%Y %H:%M')}\n")
                    temp_file.write("-" * 40 + "\n")
                    total_transactions += 1
                    total_coins += int(record['total_coin'])
            
            temp_file.write("RINGKASAN\n")
            temp_file.write("-" * 40 + "\n")
            temp_file.write(f"Jumlah Transaksi : {total_transactions}\n")
            temp_file.write(f"Total Pendapatan : {total_coins} Coin\n")
            temp_file.write("=" * 40 + "\n")

        # Kirim file ke Telegram
        try:
            caption = (f"✨ *REKAP TRANSAKSI* ✨\n"
                       "━━━━━━━━━━━━━━━━━━\n"
                       f"📅 *Bulan :* `{month_name[month]} {year}`\n"
                       f"💻 *Server :* `{server_name.upper()}`\n"
                       f"💰 *Total Coin :* `{total_coins}`\n"
                       f"🧾 *Total Transaksi :* `{total_transactions}`\n"
                       "━━━━━━━━━━━━━━━━━━\n"
                       "Silakan cek file terlampir untuk detail transaksi yang lebih lengkap.")

            await client.send_file(event.chat_id, file_name, caption=caption, parse_mode='Markdown')
            logging.info('File berhasil dikirim ke Telegram.')
        except Exception as e:
            logging.error(f"Error sending file to Telegram: {e}")

        # Menghapus file setelah dikirim
        try:
            time.sleep(2)
            os.remove(file_name)
            logging.info('File sementara telah dihapus: %s', file_name)
        except Exception as e:
            logging.error(f'Gagal menghapus file: {file_name}, Error: {e}')

    except Exception as e:
        logging.error(f"Error displaying transactions: {e}")
        await event.respond("Terjadi kesalahan saat memproses permintaan.")

async def record_transaction_to_github(server, user_id, vpn_type, label, total_coin):
    try:
        # Ambil waktu saat ini
        timestamp = datetime.now().strftime('%d-%m-%Y %H:%M')

        # Format transaksi
        transaction_record = f"{user_id} {vpn_type} {label} {total_coin} {timestamp}"

        # Load data transaksi dari file teks di GitHub
        trx_data = await load_text_data_from_github(TRX_PATH)

        # Inisialisasi data jika file kosong
        if not trx_data or not trx_data.strip():
            trx_data = ""

        # Parse data transaksi menjadi struktur dictionary
        server_data = {}
        current_server = None
        for line in trx_data.splitlines():
            line = line.strip()
            if line.endswith("["):  # Deteksi awal blok server
                current_server = line[:-1].strip()
                server_data[current_server] = []
            elif line == "]":  # Akhir blok server
                current_server = None
            elif current_server:  # Tambahkan transaksi ke server saat ini
                server_data[current_server].append(line)

        # Tambahkan transaksi baru ke server yang sesuai
        if server not in server_data:
            server_data[server] = []
        server_data[server].append(transaction_record)

        # Rekonstruksi data menjadi format teks
        updated_data = "\n".join(
            f"{srv} [\n" + "\n".join(f"  {record}" for record in records) + "\n]"
            for srv, records in server_data.items()
        )

        # Simpan kembali data ke GitHub
        await save_text_data_to_github(TRX_PATH, updated_data, "Menambahkan transaksi baru")

        logging.info(f"Transaksi berhasil dicatat untuk server {server}: {transaction_record}")
    except Exception as e:
        logging.error(f"Gagal mencatat transaksi: {e}")

