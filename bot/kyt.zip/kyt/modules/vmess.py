from kyt import *

import os
import shlex
import subprocess
import asyncio
from telethon import events, Button


def read_user_list(cmd_or_path, use_shell=False):
    """
    Membaca daftar user dari file atau perintah shell.
    
    Args:
        cmd_or_path: Perintah shell atau path file
        use_shell: Boolean, apakah menggunakan shell atau tidak
        
    Returns:
        List of strings (username entries)
    """
    try:
        if os.path.exists(cmd_or_path) and not use_shell:
            with open(cmd_or_path, "r", encoding="utf-8", errors="ignore") as f:
                return [line.strip() for line in f if line.strip()]
        else:
            completed = subprocess.run(
                cmd_or_path, 
                shell=True, 
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE, 
                text=True, 
                timeout=6
            )
            if completed.returncode != 0:
                return []
            return [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    except Exception:
        return []


def build_list_buttons(items, page, per_page, prefix):
    """
    Membangun inline keyboard untuk halaman list.
    
    Args:
        items: Daftar item
        page: Halaman saat ini
        per_page: Jumlah item per halaman
        prefix: Prefix untuk callback data
        
    Returns:
        List of button rows
    """
    start = page * per_page
    end = start + per_page
    page_items = items[start:end]
    
    buttons = []
    for idx, item in enumerate(page_items, start=1):
        cb_data = f"{prefix}:sel:{page}:{idx-1}"
        buttons.append([Button.inline(item, data=cb_data.encode())])
    
    nav = []
    if page > 0:
        nav.append(Button.inline("‹ Prev", data=f"{prefix}:nav:{page-1}".encode()))
    
    total_pages = (len(items) - 1) // per_page
    if page < total_pages:
        nav.append(Button.inline("Next ›", data=f"{prefix}:nav:{page+1}".encode()))
    
    nav.append(Button.inline("Cancel", data=f"{prefix}:cancel:0".encode()))
    
    if nav:
        buttons.append(nav)
    
    return buttons


async def start_list_flow(event, list_cmd, prefix, title, per_page=30):
    """
    Memulai flow untuk menampilkan list dan menangani events via callback query.
    
    Args:
        event: Event yang memicu
        list_cmd: Perintah untuk mendapatkan list
        prefix: Prefix untuk callback data
        title: Judul untuk pesan
        per_page: Jumlah item per halaman
    """
    sender = await event.get_sender()
    user_id = str(sender.id)

    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    items = read_user_list(list_cmd, use_shell=True)
    if not items:
        await event.edit(
            f"**{title}**\nTidak ada user ditemukan atau file/command bermasalah.",
            buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]]
        )
        return

    page = 0
    await event.edit(
        f"**{title}**\nTampilkan {len(items)} user.\nPilih username untuk melanjutkan:",
        buttons=build_list_buttons(items, page, per_page, prefix)
    )


def get_action_config(prefix_action):
    """
    Mendapatkan konfigurasi untuk aksi tertentu.
    
    Args:
        prefix_action: Nama aksi
        
    Returns:
        Tuple (list_cmd, title, action_code) atau None jika tidak dikenali
    """
    configs = {
        "delete": {
            "list_cmd": "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '",
            "title": "LIST DELETE USER",
            "action_code": "4"
        },
        "limit": {
            "list_cmd": "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '",
            "title": "CHANGE LIMIT USER",
            "action_code": "7"
        },
        "cek": {
            "list_cmd": "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '",
            "title": "CEK CONFIG USER",
            "action_code": "6"
        },
        "loginip": {
            "list_cmd": "cat /etc/vmess/listlock | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '",
            "title": "LIST MULTI LOGIN IP USER",
            "action_code": "9"
        },
        "renew": {
            "list_cmd": "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '",
            "title": "LIST RENEW USER",
            "action_code": "3"
        },
        "restore": {
            "list_cmd": "cat /etc/vmess/akundelete | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '",
            "title": "LIST AKUN RESTORE",
            "action_code": "11"
        }
    }
    
    return configs.get(prefix_action)


async def handle_trg_callback(event, prefix_action):
    """
    Menangani callback untuk aksi trg.
    
    Args:
        event: Callback event
        prefix_action: Nama aksi (delete, limit, cek, loginip, renew, restore)
    """
    data = event.data.decode()
    parts = data.split(":")
    
    if len(parts) < 2:
        await event.answer("Data callback tidak valid", alert=True)
        return
    
    typ = parts[1]
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    config = get_action_config(prefix_action)
    if not config:
        await event.answer("Aksi tidak dikenali", alert=True)
        return

    items = read_user_list(config["list_cmd"], use_shell=True)
    if not items:
        await event.edit(
            f"**{config['title']}**\nTidak ada user ditemukan.", 
            buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]]
        )
        return

    per_page = 30

    # Navigasi halaman
    if typ == "nav":
        new_page = int(parts[2])
        await event.edit(
            f"**{config['title']}**\nPilih username:",
            buttons=build_list_buttons(items, new_page, per_page, f"trg-{prefix_action}")
        )
        await event.answer()
        return

    # Cancel
    if typ == "cancel":
        await event.edit("⬤ CANCEL", buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]])
        return

    # Seleksi user
    if typ == "sel":
        page = int(parts[2])
        idx = int(parts[3])
        start = page * per_page
        
        try:
            chosen = items[start + idx]
        except Exception:
            await event.answer("Pilihan tidak valid", alert=True)
            return

        # Ambil username (strip nomor prefix bila ada)
        username = chosen.split()[-1] if chosen else chosen
        
        # Validasi bahwa username masih ada (reload source)
        fresh_items = read_user_list(config["list_cmd"], use_shell=True)
        if not any(username in line for line in fresh_items):
            await event.edit(
                f"Username '{username}' tidak ditemukan saat validasi. Silakan ulangi.",
                buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]]
            )
            return

        # Handle aksi yang membutuhkan input tambahan
        if prefix_action in ["limit", "renew", "restore"]:
            await handle_input_actions(event, prefix_action, config["action_code"], username, config["title"])
        else:
            # Handle aksi tanpa input tambahan
            await handle_simple_action(event, prefix_action, config["action_code"], username)
        
        return

    await event.answer()


async def handle_input_actions(event, action_type, action_code, username, title):
    """
    Menangani aksi yang membutuhkan input tambahan.
    
    Args:
        event: Callback event
        action_type: Tipe aksi (limit, renew, restore)
        action_code: Kode aksi untuk m-vmess
        username: Username yang dipilih
        title: Judul aksi
    """
    chat_id = event.chat_id
    sender = await event.get_sender()
    
    if action_type == "limit":
        await event.edit(
            f"Input New Limit IP Login untuk user: {username}",
            buttons=[[Button.inline("Batal", data=f"trg-{action_type}:cancel:0".encode())]]
        )
        
        try:
            async with bot.conversation(chat_id, timeout=300) as conv:
                msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                text = msg.raw_text.strip()
                
                if text.lower() == "/cancel":
                    await conv.send_message("⬤ CANCEL", buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]])
                    return
                
                new_limit = shlex.quote(text)
                cmd = f'printf "%s\\n" "{action_code}" "{username}" "{new_limit}" | m-vmess'
                
                await execute_command(event, cmd, "⬤ SUCCESS CHANGE")
                
        except asyncio.TimeoutError:
            await event.respond(
                "Timeout input. Silakan mulai ulang aksi.", 
                buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]]
            )
    
    elif action_type == "renew":
        await event.edit(
            f"Masukkan jumlah hari perpanjangan untuk user: {username}",
            buttons=[[Button.inline("Cancel", data=f"trg-{action_type}:cancel:0".encode())]]
        )
        
        try:
            async with bot.conversation(chat_id, timeout=180) as conv:
                msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                text = msg.raw_text.strip()
                
                if text.lower() == "/cancel":
                    await conv.send_message("⬤ CANCEL", buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]])
                    return
                
                exp = shlex.quote(text)
                cmd = f'printf "%s\\n" "{action_code}" "{username}" "{exp}" | m-vmess'
                
                await execute_command(event, cmd, "⬤ SUCCESS RENEW")
                
        except asyncio.TimeoutError:
            await event.respond(
                "Timeout input. Silakan mulai ulang aksi.", 
                buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]]
            )
    
    elif action_type == "restore":
        await event.edit(
            f"Masukkan expired (hari) untuk user: {username}",
            buttons=[[Button.inline("Cancel", data=f"trg-{action_type}:cancel:0".encode())]]
        )
        
        try:
            async with bot.conversation(chat_id, timeout=180) as conv:
                msg1 = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                text1 = msg1.raw_text.strip()
                
                if text1.lower() == "/cancel":
                    await conv.send_message("⬤ CANCEL", buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]])
                    return
                
                exp = shlex.quote(text1)
                
                await conv.send_message(
                    "Masukkan New Limit IP Login untuk user:",
                    buttons=[[Button.inline("Cancel", data=f"trg-{action_type}:cancel:0".encode())]]
                )
                
                msg2 = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                text2 = msg2.raw_text.strip()
                
                if text2.lower() == "/cancel":
                    await conv.send_message("⬤ CANCEL", buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]])
                    return
                
                limit_ip = shlex.quote(text2)
                cmd = f'printf "%s\\n" "{action_code}" "{username}" "{exp}" "{limit_ip}" | m-vmess'
                
                await execute_command(event, cmd, "⬤ SUCCESS RESTORE")
                
        except asyncio.TimeoutError:
            await event.respond(
                "Timeout input. Silakan mulai ulang aksi.", 
                buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]]
            )


async def handle_simple_action(event, action_type, action_code, username):
    """
    Menangani aksi yang tidak membutuhkan input tambahan.
    
    Args:
        event: Callback event
        action_type: Tipe aksi (delete, cek, loginip)
        action_code: Kode aksi untuk m-vmess
        username: Username yang dipilih
    """
    cmd = f'printf "%s\\n" "{action_code}" "{username}" | m-vmess'
    
    success_messages = {
        "delete": "⬤ SUCCESS DELETE",
        "cek": "⬤ SUCCESS CEK AKUN",
        "loginip": "⬤ SUCCESS UNLOCK"
    }
    
    success_msg = success_messages.get(action_type, "⬤ SUCCESS")
    
    await execute_command(event, cmd, success_msg)


async def execute_command(event, cmd, success_msg):
    """
    Menjalankan perintah shell dan menangani hasilnya.
    
    Args:
        event: Callback event
        cmd: Perintah shell yang akan dijalankan
        success_msg: Pesan sukses yang akan dikirim
    """
    try:
        subprocess.run(
            cmd, 
            shell=True, 
            check=True, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True, 
            timeout=25
        )
        await event.respond(success_msg, buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]])
    except subprocess.CalledProcessError as e:
        await event.respond(
            f"Terjadi error saat menjalankan perintah: {e.stderr}", 
            buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]]
        )
    except Exception as e:
        await event.respond(
            f"Terjadi error saat menjalankan perintah: {e}", 
            buttons=[[Button.inline("⟨ MENU ⟩", data=b"menu")]]
        )


# Central callback handler untuk semua aksi trg-*
@bot.on(events.CallbackQuery(data=lambda d: d and d.decode().startswith("trg-")))
async def on_trg_callback(event):
    data = event.data.decode()
    try:
        head = data.split(":")[0]
        prefix_action = head.split("-", 1)[1]  # e.g. delete / limit / cek / loginip / renew / restore
        await handle_trg_callback(event, prefix_action)
    except Exception:
        await event.answer("Data callback tidak valid", alert=True)


# Starter callbacks untuk membuka list dengan prefix yang berbeda
@bot.on(events.CallbackQuery(data=b'delete7-vmess'))
async def cb_delete7(event):
    await start_list_flow(
        event,
        "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '",
        "trg-delete",
        "LIST DELETE USER"
    )


@bot.on(events.CallbackQuery(data=b'limit7-vmess'))
async def cb_limit7(event):
    await start_list_flow(
        event,
        "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '",
        "trg-limit",
        "CHANGE LIMIT USER"
    )


@bot.on(events.CallbackQuery(data=b'akun7-vmess'))
async def cb_akun7(event):
    await start_list_flow(
        event,
        "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '",
        "trg-cek",
        "CEK CONFIG USER"
    )


@bot.on(events.CallbackQuery(data=b'loginip7-vmess'))
async def cb_loginip7(event):
    await start_list_flow(
        event,
        "cat /etc/vmess/listlock | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '",
        "trg-loginip",
        "LIST MULTI LOGIN IP USER"
    )


@bot.on(events.CallbackQuery(data=b'renew7-vmess'))
async def cb_renew7(event):
    await start_list_flow(
        event,
        "cat /etc/xray/config.json | grep '^#vmg' | cut -d ' ' -f 2-3 | nl -s ') '",
        "trg-renew",
        "LIST RENEW USER"
    )


@bot.on(events.CallbackQuery(data=b'restore7-vmess'))
async def cb_restore7(event):
    await start_list_flow(
        event,
        "cat /etc/vmess/akundelete | grep '^###' | cut -d ' ' -f 2-3 | nl -s ') '",
        "trg-restore",
        "LIST AKUN RESTORE"
    )


# CREATE VMESS
@bot.on(events.CallbackQuery(data=b'create7-vmess'))
async def create_vmess(event):
    sender = await event.get_sender()

    # Cek akses
    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    async def create_vmess_flow():
        # === Input awal: username expired limit_ip ===
        await event.edit(
            "**Masukkan data: username expired(hari) limit_ip**\n"
            "(Contoh: user1 30 2)",
            buttons=[[Button.inline("Batal", b"cancel")]]
        )

        try:
            response = await bot.wait_event(
                events.NewMessage(incoming=True, from_users=sender.id),
                timeout=300
            )
        except asyncio.TimeoutError:
            return await event.respond("Waktu habis.", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

        text = response.raw_text.strip()
        if not text or text.lower() == "/cancel":
            return await event.respond("⬤ CANCEL", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

        parts = text.split()
        if len(parts) != 3:
            return await event.respond("Format salah. Gunakan: username expired limit_ip",
                                       buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

        username, expired, limit_ip = parts

        # === Loop validasi username saja ===
        while True:
            try:
                existing_users = subprocess.check_output(
                    "grep '^#vmg' /etc/xray/config.json || true", shell=True
                ).decode().splitlines()
            except Exception:
                existing_users = []

            if any(username in line for line in existing_users):
                await event.respond(
                    f"Username '{username}' sudah ada, masukkan username lain:",
                    buttons=[[Button.inline("Batal", b"cancel")]]
                )
                try:
                    resp_user = await bot.wait_event(
                        events.NewMessage(incoming=True, from_users=sender.id),
                        timeout=300
                    )
                except asyncio.TimeoutError:
                    return await event.respond("Waktu habis.", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

                new_username = resp_user.raw_text.strip()
                if not new_username or new_username.lower() == "/cancel":
                    return await event.respond("⬤ CANCEL", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

                username = new_username
                continue  # cek ulang username baru
            break  # username valid → keluar loop

        # === Eksekusi perintah ===
        cmd = f'printf "%s\n" "1" "{username}" "{expired}" "{limit_ip}" | m-vmess'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(
                f"User '{username}' berhasil dibuat.",
                buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
            )
        except subprocess.CalledProcessError as e:
            await event.respond(
                f"Gagal membuat user: {e}",
                buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]]
            )

    await create_vmess_flow()


# TRIAL VMESS
@bot.on(events.CallbackQuery(data=b'trial7-vmess'))
async def trial_vmess(event):
    chat_id = event.chat_id
    sender = await event.get_sender()
    sender_id = str(sender.id)

    if not await check_access(event):
        return await event.answer("Akses Ditolak", alert=True)

    async def trial_vmess_flow():
        await event.edit(
            "**Masukkan durasi trial (menit):**",
            buttons=[[Button.inline("Batal", b"cancel")]]
        )

        try:
            response = await bot.wait_event(
                events.NewMessage(incoming=True, from_users=sender.id),
                timeout=300
            )
        except asyncio.TimeoutError:
            return await event.respond("Waktu habis.", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

        text = response.raw_text.strip()
        if not text or text.lower() == "/cancel":
            return await event.respond("⬤ CANCEL", buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

        if not text.isdigit():
            return await event.respond("Durasi harus angka.",
                                       buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

        cmd = f'printf "%s\n" "2" "{text}" | m-vmess'
        try:
            subprocess.check_output(cmd, shell=True)
            await event.respond(f"Trial {text} menit berhasil dibuat.",
                                buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])
        except subprocess.CalledProcessError as e:
            await event.respond(f"Gagal membuat trial: {e}",
                                buttons=[[Button.inline("⟨ MENU ⟩", b"menu")]])

    await trial_vmess_flow()


# MENU VMESS
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess(event):
    # Cek akses
    if not await check_access(event):
        return await event.answer("Access Denied", alert=True)

    # Susunan tombol menu
    inline_buttons = [
        [
            Button.inline("Trial", b"trial7-vmess"),
            Button.inline("Create", b"create7-vmess"),
            Button.inline("Restore", b"restore7-vmess")
        ],
        [
            Button.inline("Delete", b"delete7-vmess"),
            Button.inline("Unlock", b"loginip7-vmess"),
            Button.inline("Limit", b"limit7-vmess")
        ],
        [
            Button.inline("Renew", b"renew7-vmess"),
            Button.inline("Akun", b"akun7-vmess"),
            Button.inline("⟨ MENU ⟩", b"menu")
        ]
    ]

    # Ambil informasi server (aman walau file tidak ada)
    ip_addr   = safe_file("/etc/myipvps")
    domainz   = safe_file("/etc/xray/domain")
    isp       = safe_file("/etc/xray/isp")
    city      = safe_file("/etc/xray/city")
    profil    = safe_file("/etc/profil")
    time_info = safe_exec("LC_TIME=id_ID.UTF-8 date '+%A, %d %B %Y - %H:%M WIB'")

    # Pesan informasi panel
    msg = (
        "━━━━━━━━━━━━━━━━━━━━\n"
        "**PANEL XIESTORE**\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"**IP :** {ip_addr}\n"
        f"**Domain :** {domainz}\n"
        f"**ISP :** {isp}\n"
        f"**Kota :** {city}\n"
        f"**Profil :** {profil}\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"__{time_info}__"
    )

    # Tampilkan menu
    await event.edit(msg, buttons=inline_buttons)
