from telethon import *
from telethon import TelegramClient, events, Button
import datetime as dt
import requests
import time
import os
import subprocess
import re
import sqlite3
import sys
import random
import base64
import json
import math
import logging

# Konfigurasi logging
logging.basicConfig(level=logging.INFO)

# Load variabel dari file eksternal
with open("kyt/var.txt", "r") as f:
    exec(f.read())

# Inisialisasi bot Telegram
bot = TelegramClient(
    "ddsdswl",
    "6",
    "eb06d4abfb49dc3eeb1aeb98ae0f581e"
).start(bot_token=BOT_TOKEN)

# Inisialisasi database jika belum ada
if not os.path.exists("kyt/database.db"):
    conn = sqlite3.connect("kyt/database.db")
    cur = conn.cursor()
    cur.execute("CREATE TABLE admin (user_id)")
    cur.execute("INSERT INTO admin (user_id) VALUES (?)", (ADMIN,))
    conn.commit()
    conn.close()

def get_db():
    """Membuka koneksi ke database SQLite."""
    conn = sqlite3.connect("kyt/database.db")
    conn.row_factory = sqlite3.Row
    return conn

def valid(user_id):
    """Memeriksa apakah user_id terdaftar sebagai admin."""
    db = get_db()
    rows = db.execute("SELECT user_id FROM admin").fetchall()
    db.close()
    admin_ids = [row[0] for row in rows]
    return "true" if user_id in admin_ids else "false"

def convert_size(size_bytes):
    """Mengonversi ukuran byte menjadi format yang lebih mudah dibaca."""
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"

def safe_exec(cmd):
    """Eksekusi shell command dengan aman, kembalikan output atau '-' jika gagal."""
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True).strip()
    except Exception:
        return "-"

def safe_file(path, default="-"):
    """Baca file dengan aman, kembalikan default jika tidak ada."""
    try:
        if os.path.exists(path):
            with open(path, "r") as f:
                return f.read().strip() or default
    except Exception:
        pass
    return default

def safe_count(pattern, filepath):
    """Hitung jumlah baris yang mengandung pattern di file, aman jika file tidak ada."""
    if not os.path.exists(filepath):
        return "0"
    try:
        cmd = f'grep -c "{pattern}" "{filepath}"'
        result = subprocess.check_output(cmd, shell=True).decode("utf-8").strip()
        return result if result.isdigit() else "0"
    except subprocess.CalledProcessError:
        return "0"

async def check_access(event):
    """Validasi user, kembalikan True jika diizinkan."""
    sender = await event.get_sender()
    return valid(str(sender.id)) == "true"
